document.addEventListener('DOMContentLoaded', function() {
    // eslint-disable-next-line no-undef
    yall({ observeChanges: !0 });
});
var animateHTML = function() {
    var e, t;
    function n() {
        (e = document.querySelectorAll('.raheem--hidden')), (t = window.innerHeight), window.addEventListener('scroll', r), window.addEventListener('resize', n), r();
    }
    function r() {
        for (var n = 0; n < e.length; n++) {
            e[n].getBoundingClientRect().top - t <= 0 && (e[n].className = e[n].className.replace('raheem--hidden', 'raheem--fade-in-element'));
        }
    }
    return { init: n };
};
function _extends() {
    // eslint-disable-next-line no-func-assign
    return (_extends =
        Object.assign ||
        function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
        }).apply(this, arguments);
}
animateHTML().init(),
    (window.yall = function(e) {
        var t = function(e) {
                if ('IMG' === e.tagName) {
                    var t = e.parentNode;
                    'PICTURE' === t.tagName &&
                        [].slice.call(t.querySelectorAll('source')).forEach(function(e) {
                            return n(e);
                        }),
                        n(e);
                }
                'VIDEO' === e.tagName &&
                    ([].slice.call(e.querySelectorAll('source')).forEach(function(e) {
                        return n(e);
                    }),
                    n(e),
                    !0 === e.autoplay && e.load()),
                    'IFRAME' === e.tagName && ((e.src = e.dataset.src), e.removeAttribute('data-src')),
                    e.classList.contains(o.lazyBackgroundClass) && (e.classList.remove(o.lazyBackgroundClass), e.classList.add(o.lazyBackgroundLoaded));
            },
            n = function(e) {
                for (var t in e.dataset) -1 !== a.acceptedDataAttributes.indexOf('data-' + t) && (e.setAttribute(t, e.dataset[t]), e.removeAttribute('data-' + t));
            },
            r = function e() {
                var n = !1;
                !1 === n &&
                    0 < l.length &&
                    ((n = !0),
                    setTimeout(function() {
                        l.forEach(function(e) {
                            e.getBoundingClientRect().top <= window.innerHeight + o.threshold &&
                                e.getBoundingClientRect().bottom >= -o.threshold &&
                                'none' !== getComputedStyle(e).display &&
                                (!0 === o.idlyLoad && !0 === a.idleCallbackSupport
                                    ? requestIdleCallback(function() {
                                          t(e);
                                      }, s)
                                    : t(e),
                                e.classList.remove(o.lazyClass),
                                (l = l.filter(function(t) {
                                    return t !== e;
                                })));
                        }),
                            (n = !1),
                            0 === l.length &&
                                !1 === o.observeChanges &&
                                a.eventsToBind.forEach(function(t) {
                                    return t[0].removeEventListener(t[1], e);
                                });
                    }, o.throttleTime));
            },
            a = {
                intersectionObserverSupport: 'IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype,
                mutationObserverSupport: 'MutationObserver' in window,
                idleCallbackSupport: 'requestIdleCallback' in window,
                ignoredImgAttributes: ['data-src', 'data-sizes', 'data-media', 'data-srcset', 'src', 'srcset'],
                acceptedDataAttributes: ['data-src', 'data-sizes', 'data-media', 'data-srcset', 'data-poster'],
                eventsToBind: [[document, 'scroll'], [document, 'touchmove'], [window, 'resize'], [window, 'orientationchange']]
            },
            o = _extends({ lazyClass: 'lazy', lazyBackgroundClass: 'lazy-bg', lazyBackgroundLoaded: 'lazy-bg-loaded', throttleTime: 200, idlyLoad: !1, idleLoadTimeout: 100, threshold: 200, observeChanges: !1, observeRootSelector: 'body', mutationObserverOptions: { childList: !0 } }, e),
            i = 'img.' + o.lazyClass + ',video.' + o.lazyClass + ',iframe.' + o.lazyClass + ',.' + o.lazyBackgroundClass,
            s = { timeout: o.idleLoadTimeout },
            l = [].slice.call(document.querySelectorAll(i));
        if (!0 === a.intersectionObserverSupport) {
            var c = new IntersectionObserver(
                function(e, n) {
                    e.forEach(function(e) {
                        if (!0 === e.isIntersecting || 0 < e.intersectionRatio) {
                            var r = e.target;
                            !0 === o.idlyLoad && !0 === a.idleCallbackSupport
                                ? requestIdleCallback(function() {
                                      return t(r);
                                  }, s)
                                : t(r),
                                r.classList.remove(o.lazyClass),
                                n.unobserve(r),
                                (l = l.filter(function(e) {
                                    return e !== r;
                                }));
                        }
                    });
                },
                { rootMargin: o.threshold + 'px 0%' }
            );
            l.forEach(function(e) {
                return c.observe(e);
            });
        } else
            a.eventsToBind.forEach(function(e) {
                return e[0].addEventListener(e[1], r);
            }),
                r();
        !0 === a.mutationObserverSupport &&
            !0 === o.observeChanges &&
            new MutationObserver(function(e) {
                return e.forEach(function() {
                    [].slice.call(document.querySelectorAll(i)).forEach(function(e) {
                        -1 === l.indexOf(e) && (l.push(e), !0 === a.intersectionObserverSupport ? c.observe(e) : r());
                    });
                });
            }).observe(document.querySelector(o.observeRootSelector), o.mutationObserverOptions);
    });
